# Fantasy-Companion

## Notes

Created by Rick from the SWADE Fantasy Companion v1.3

Updating to v1.5 values

## Version update process

Amend version in ...

* this document

* module.json

* runBuild-Fantasy-Companion.cmd

## Changes

Version: 0.0.4  

Version: 0.0.5  

Version: 0.0.6  

Version: 0.0.7  

Version: 0.0.8  

Version: 0.0.9  

Version: 0.0.10

Version: 0.0.11

Version: 0.0.12

Version: 0.0.13

Version: 0.0.14

Version: 0.0.15

Version: 0.0.16

Version: 0.1.1
