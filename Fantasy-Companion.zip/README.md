# Fantasy-Companion

## Notes

Created by Rick from the SWADE Fantasy Companion v1.3

Updating to v1.5 values

## Version update process

Amend version in ...

* this document

* module.json

* runBuild-Fantasy-Companion.cmd

## Changes

Version: 0.0.4  

Version: 0.0.5  

Version: 0.0.6  

Version: 0.0.7  

Version: 0.0.8  

Version: 0.0.9  

Version: 0.0.10

Version: 0.0.11

Version: 0.0.12

Version: 0.0.13

Version: 0.0.14

Version: 0.0.15

Version: 0.0.16

Version: 0.1.1

Version: 0.1.2

Version: 0.1.3

Version: 0.1.4

Version: 0.1.5 manually added item

Version: 0.2.1 attempt to start breaking into multiple pack db files

Version: 0.2.2

Version: 0.2.3 hindrances in-progress and skills done

Version: 0.2.4 hindrances tweaked

Version: 0.2.5 Alchemy to Smarts, other hindrances to system rather than data, as they weren't exported then imported

Version: 0.2.6 attempt to fix Hindrances

Version: 0.2.7 Cursed, Grim, Jingoistic, Material Components, Selfless & Talisman corrections.

Version: 0.2.8 Druid's Heartstaff and Great Sword two-handed

Version: 0.2.9 remove edges & hindrances from equipment pack ... fix Great Sword

Version: 0.2.10 remove powers from equipment pack, add new powers pack

Version: 0.2.11 rename build-scripts, pull back skills & FC packs to code

Version: 0.2.12 add missing powers

Version: 0.2.13 !!! messed up, overwrote all the work on Edges !!!

Version: 0.2.14 (re)added the edges including abridged Arcane Backgrounds
