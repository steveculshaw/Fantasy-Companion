# Fantasy-Companion

Created by Rick from the SWADE Fantasy Companion v1.3

Updating to v1.5 values

Version: 0.0.4 ... started clean-up

Version: 0.0.5 ... start updating weapons

Version: 0.0.6 ... not checking in local files, only zip

Version: 0.0.7 ... just build