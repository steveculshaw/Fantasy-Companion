# Fantasy-Companion

## Notes

Created by Rick from the SWADE Fantasy Companion v1.3

Updating to v1.5 values

## Version update process

Amend version in ...

* this document

* module.json

* runBuild-Fantasy-Companion.cmd

## Changes

Version: 0.0.4 ... started clean-up

Version: 0.0.5 ... start updating weapons

Version: 0.0.6 ... not checking in local files, only zip

Version: 0.0.7 ... just build check

Version: 0.0.8 ... swords done

Version: 0.0.8 ... axes done
