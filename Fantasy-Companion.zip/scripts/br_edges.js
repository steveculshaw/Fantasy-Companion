const groupName = "Fantasy-Companion";
const edgesGroupName = "Edges";
const starIcon = "☆ ";

export const edges = [
  //
  // think some of these edges are from Savage Worlds for Pathfinder
  //
  // {
  //   id: "MONKRAISE",
  //   name: "Monk",
  //   button_name: "Monk",
  //   defaultChecked: "on",
  //   raiseDamageFormula: "+1d10x",
  //   and_selector: [{
  //     selector_type: "actor_has_edge",
  //     selector_value: "Monk"
  //   },
  //   {
  //     selector_type: "skill",
  //     selector_value: "Fighting"
  //   }
  //   ],
  //   group: groupName
  // },
  // {
  //   id: "ARCANEARCHER01",
  //   name: "Arcane Archer",
  //   button_name: "Arcane Archer",
  //   skillMod: "+1",
  //   dmgMod: "+1",
  //   defaultChecked: "on",
  //   and_selector: [{
  //     selector_type: "actor_has_edge",
  //     selector_value: "Arcane Archer"
  //   },
  //   {
  //     selector_type: "skill",
  //     selector_value: "Shooting"
  //   },
  //   {
  //     selector_type: "item_type",
  //     selector_value: "weapon"
  //   }
  //   ],
  //   group: groupName
  // },
  // {
  //   id: "POWERFULBLOW01",
  //   name: "Powerful Blow",
  //   button_name: "Powerful Blow (Wild Attack)",
  //   skillMod: "+2",
  //   dmgMod: "+4",
  //   and_selector: [{
  //     selector_type: "actor_has_edge",
  //     selector_value: "Powerful Blow"
  //   },
  //   {
  //     selector_type: "skill",
  //     selector_value: "Fighting"
  //   },
  //   {
  //     selector_type: "item_type",
  //     selector_value: "weapon"
  //   }
  //   ],
  //   group: groupName,
  //   self_add_status: "vulnerable"
  // },
  // {
  //   id: "DEADLYBLOW01",
  //   name: "Deadly Blow",
  //   button_name: "Deadly Blow",
  //   dmgMod: "+1",
  //   defaultChecked: "on",
  //   and_selector: [{
  //     selector_type: "actor_has_edge",
  //     selector_value: "Deadly Blow"
  //   },
  //   {
  //     selector_type: "item_type",
  //     selector_value: "weapon"
  //   }
  //   ],
  //   group: groupName
  // },
  {
    id: "SNEAKATTACK",
    name: "Sneak Attack",
    button_name: "Sneak Attack",
    dmgMod: "+1d6x",
    and_selector: [
      {
        selector_type: "actor_has_edge",
        selector_value: "Rogue"
      },
      {
        selector_type: "skill",
        selector_value: "Fighting"
      }
    ],
    group: groupName
  },
  {
    id: "EDGEWORKTHEROOM",
    name: "Work the room",
    button_name: "Work the room",
    rof: "2",
    and_selector: [
      {
        selector_type: "actor_has_edge",
        selector_value: "Work the Room"
      },
      {
        or_selector: [
          {
            selector_type: "skill",
            selector_value: "Performance"
          },
          {
            selector_type: "skill",
            selector_value: "Persuasion"
          }
        ]
      }
    ],
    group: edgesGroupName
  },
  {
    id: "EDGEFRENZY",
    name: "Frenzy",
    button_name: "BRSW.EdgeName-Frenzy",
    and_selector: [
      {
        selector_type: "skill",
        selector_value: "Fighting"
      },
      {
        selector_type: "actor_has_edge",
        selector_value: "Frenzy"
      }
    ],
    defaultChecked: "on",
    group: edgesGroupName,
    rof: "2"
  },
  {
    id: "EDGEIMPROVEDFRENZY",
    name: "Improved Frenzy",
    button_name: "Improved Frenzy",
    and_selector: [
      {
        selector_type: "skill",
        selector_value: "Fighting"
      },
      {
        selector_type: "actor_has_edge",
        selector_value: "Improved Frenzy"
      }
    ],
    defaultChecked: "on",
    group: edgesGroupName,
    rof: "3"
  },
  {
    id: "Savagery",
    name: "Wild Attack (Savagery)",
    button_name: "Wild Attack (Savagery)",
    dmgMod: "+4",
    and_selector: [
      {
        selector_type: "actor_has_edge",
        selector_value: "Savagery"
      },
      {
        selector_type: "skill",
        selector_value: "Fighting"
      }
    ],
    group: edgesGroupName
  }
];
